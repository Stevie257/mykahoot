# Kaspammer Kahoot Flooder 

Easy to use kahoot.js flooder

[Click Me To Go To Website](https://yeetedmeme.js.org/kaspammer)

Use the above link to use the website yourself without editing anything

# Setting It Up For Yourself

Clone The repo then edit it with your git editor (I prefer github desktop and vs code)

Edit `"I like ya cut g "` on line 119 of server.js to change the name of the bot, make sure to add a space at the end so the bot number wont be part of your text

# Using The Bot

On the website (linked above) or own your own creation, fill out the game pin and number of bots (max is 250) then click on flood to flood the game!

# Enjoy!
